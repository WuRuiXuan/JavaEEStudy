create
    definer = root@localhost procedure proc(IN name varchar(50), OUT s varchar(100))
BEGIN
set s = concat('hello ', name);
END;

